---
dataset_info:
  features:
  - name: query
    dtype: string
  - name: choices
    sequence: string
  - name: gold
    sequence: int64
  splits:
  - name: test
    num_bytes: 923886
    num_examples: 510
  download_size: 469922
  dataset_size: 923886
configs:
- config_name: default
  data_files:
  - split: test
    path: data/test-*
---

# Dataset Card for "agieval-lsat-lr"


Dataset taken from https://github.com/microsoft/AGIEval and processed as in that repo, following dmayhem93/agieval-* datasets on the HF hub.

This dataset contains the contents of the LSAT-logical reasoning subtask of AGIEval, as accessed in https://github.com/ruixiangcui/AGIEval/commit/5c77d073fda993f1652eaae3cf5d04cc5fd21d40 .


Citation:


@misc

{zhong2023agieval,
title={AGIEval: A Human-Centric Benchmark for Evaluating Foundation Models},
author={Wanjun Zhong and Ruixiang Cui and Yiduo Guo and Yaobo Liang and Shuai Lu and Yanlin Wang and Amin Saied and Weizhu Chen and Nan Duan},
year={2023},
eprint={2304.06364},
archivePrefix={arXiv},
primaryClass={cs.CL}
}