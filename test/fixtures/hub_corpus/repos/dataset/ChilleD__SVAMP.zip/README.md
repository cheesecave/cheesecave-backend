---
language:
- en
license: mit
size_categories:
- n<1K
task_categories:
- text-generation
dataset_info:
  features:
  - name: ID
    dtype: string
  - name: Body
    dtype: string
  - name: Question
    dtype: string
  - name: Equation
    dtype: string
  - name: Answer
    dtype: string
  - name: Type
    dtype: string
  - name: question_concat
    dtype: string
  splits:
  - name: train
    num_bytes: 273253
    num_examples: 700
  - name: test
    num_bytes: 117208.0
    num_examples: 300
  download_size: 166226
  dataset_size: 390461.0
configs:
- config_name: default
  data_files:
  - split: train
    path: data/train-*
  - split: test
    path: data/test-*
---
