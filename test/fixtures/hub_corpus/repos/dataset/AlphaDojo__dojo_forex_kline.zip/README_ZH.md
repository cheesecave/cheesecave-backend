> **Languages:** [简体中文](README_ZH.md) · [English](README.md)

# dojo_forex_kline — 外汇 K 线

## 概述

主要**货币对**的日 K 线（OHLC + 振幅），用于在报表币种与上市地/分析币种不一致时，将营收、利润等金额**换算为统一货币**。

典型场景：[dojo_main_income](https://huggingface.co/datasets/AlphaDojo/dojo_main_income) 中地区收入以**港元**记账，分析口径为**美元**时，需用 `HKDUSD` 等汇率按报告日折算。

## 设计用途：营收结构货币换算

[dojo_main_income](https://huggingface.co/datasets/AlphaDojo/dojo_main_income) 地区维度（`mainop_type = 3`）与 [dojo_fin_indicators](https://huggingface.co/datasets/AlphaDojo/dojo_fin_indicators) 的 `currency` 记录的是**报表原始币种**金额。以下情况需要本数据集：

| 情况 | 说明 |
|------|------|
| 上市市场 ≠ 报表币种 | 例如地区收入为 HKD，分析基准为 USD |
| 跨地区收入对比 | 将 CNY / HKD / USD 等分项换算到同一货币再算占比 |
| 与行情估值对齐 | 市值、股价以交易货币计价，收入拆解需同币种 |

### 换算流程（参考）

1. 从 `dojo_main_income` 读取分项收入及 `currency`。
2. 从 `dojo_stock_info` 确定上市市场与目标展示货币。
3. 按 `report_date` 从本数据集取汇率（如 `HKDUSD`、`USDCNY`）。
4. 换算各分项 `main_business_income` 后重算 `mbi_ratio`。

### 示例

```
报表：地区「香港」= 10 亿港元（currency: HKD）
目标：以 USD 展示

取 report_date 当日 HKD-USD 收盘价 → 10 亿 HKD × 汇率 ≈ X 亿美元
```

`close` / `open`、报告期末 / 披露日取价，由使用方在自有流程中统一约定。

## 文件

| 文件 | 说明 |
|------|------|
| `data.parquet` | 外汇日 K 线 |

## 关键字段

| 字段 | 说明 |
|------|------|
| `symbol` | 货币对（如 `HKDUSD`、`USDCNY`） |
| `bar_time` | 交易日 |
| `open` / `close` / `high` / `low` | OHLC；换算通常以 `close` 为参考 |
| `amplitude` | 振幅 |

## 数据规模（参考）

约 **1000** 行（少量货币对 × 有限交易日窗口）。

## 与 dojo_stock_kline 的差异

| 对比项 | dojo_stock_kline | dojo_forex_kline |
|--------|------------------|------------------|
| 标的 | 股票 | 货币对 |
| 字段 | 含 vol、复权、分红拆股 | 含 amplitude，无成交量 |
| 主要用途 | 价格走势 | 财报金额跨币种换算 |

## 关联数据集

- [dojo_main_income](https://huggingface.co/datasets/AlphaDojo/dojo_main_income) — 待换算的收入分项
- [dojo_fin_indicators](https://huggingface.co/datasets/AlphaDojo/dojo_fin_indicators) — `currency`、总营收与利润
- [dojo_stock_info](https://huggingface.co/datasets/AlphaDojo/dojo_stock_info) — 上市市场
- [dojo_quote](https://huggingface.co/datasets/AlphaDojo/dojo_quote) — 报价货币
