---
license: apache-2.0
---

> **Languages:** [简体中文](README_ZH.md) · [English](README.md)

# dojo_forex_kline — FX Daily Bars

## Overview

Daily OHLC and amplitude for major currency pairs. Used to convert revenue, profit, and other filing amounts into a **single currency** when report currency and listing/analysis currency differ.

Typical case: regional revenue in **HKD** in [dojo_main_income](https://huggingface.co/datasets/AlphaDojo/dojo_main_income) while analysis targets **USD** — apply `HKDUSD` (or equivalent) at the report date.

## Intended Use: Cross-Currency Revenue Breakdown

[dojo_main_income](https://huggingface.co/datasets/AlphaDojo/dojo_main_income) region slices (`mainop_type = 3`) and [dojo_fin_indicators](https://huggingface.co/datasets/AlphaDojo/dojo_fin_indicators) `currency` store amounts in **original report currency**. This dataset is needed when:

| Scenario | Description |
|----------|-------------|
| Listing market ≠ report currency | e.g. HKD regional revenue vs USD analysis |
| Cross-region mix | Normalize CNY / HKD / USD segments before computing mix % |
| Valuation alignment | Market cap and price are in trading currency; revenue mix needs the same unit |

### Conversion Flow (reference)

1. Read segment revenue and `currency` from `dojo_main_income`.
2. Determine target currency from listing market in `dojo_stock_info`.
3. Fetch FX rate for `report_date` from this dataset (e.g. `HKDUSD`, `USDCNY`).
4. Convert `main_business_income` and recompute `mbi_ratio`.

### Example

```
Filing: Region "Hong Kong" = HKD 1.0B (currency: HKD)
Target: USD presentation

FX on report_date: HKD-USD close → HKD 1.0B × rate ≈ USD X.XB
```

Use `close` vs `open` and period-end vs filing date consistently in your own pipeline.

## Files

| File | Description |
|------|-------------|
| `data.parquet` | FX daily bars |

## Key Fields

| Field | Description |
|-------|-------------|
| `symbol` | Currency pair (e.g. `HKDUSD`, `USDCNY`) |
| `bar_time` | Trade date |
| `open` / `close` / `high` / `low` | OHLC; `close` is the usual conversion reference |
| `amplitude` | Daily amplitude |

## Scale (reference)

~**1k** rows (few pairs × limited date window).

## Comparison with dojo_stock_kline

| Aspect | dojo_stock_kline | dojo_forex_kline |
|--------|------------------|------------------|
| Underlying | Equities | Currency pairs |
| Fields | vol, adjustment, dividends/splits | amplitude, no volume |
| Primary use | Price history | Cross-currency filing amounts |

## Related Datasets

- [dojo_main_income](https://huggingface.co/datasets/AlphaDojo/dojo_main_income) — revenue segments to convert
- [dojo_fin_indicators](https://huggingface.co/datasets/AlphaDojo/dojo_fin_indicators) — `currency`, total revenue and profit
- [dojo_stock_info](https://huggingface.co/datasets/AlphaDojo/dojo_stock_info) — listing market
- [dojo_quote](https://huggingface.co/datasets/AlphaDojo/dojo_quote) — quote currency
