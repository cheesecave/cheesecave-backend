## Downloads across every package Thyn publishes — 2026-10-15T05:34:00Z

57 packages and release channels on PyPI, npm, GitHub and the Hugging Face Hub. Every number is read from the registry's own API and refreshed twice a day; PyPI's download log runs through 2026-10-13.


| Window | All registries | PyPI | npm | Hugging Face kernels | GitHub release assets |
|---|---:|---:|---:|---:|---:|
| Last 7 days | 9,177 (PyPI + npm) | 8,819 | 358 | n/a | n/a |
| Last 30 days | 110,519 | 97,868 | 12,491 | 160 | n/a |
| All time | 200,222 | 175,922 | 23,623 | 160 | 517 |

### PyPI

| Package | 7 days | 30 days | All time |
|---|---:|---:|---:|
| [codna](https://pypi.org/project/codna/) | 3,521 | 43,250 | 86,739 |
| [algenta-sdk](https://pypi.org/project/algenta-sdk/) | 1,438 | 13,993 | 19,344 |
| [algenta-mcp](https://pypi.org/project/algenta-mcp/) | 1,300 | 12,885 | 17,290 |
| [algenta](https://pypi.org/project/algenta/) | 688 | 6,224 | 9,116 |
| [telys](https://pypi.org/project/telys/) | 283 | 3,253 | 12,096 |
| [bm25-mojo](https://pypi.org/project/bm25-mojo/) | 116 | 1,964 | 1,964 |
| [cclib-mojo](https://pypi.org/project/cclib-mojo/) | 90 | 1,885 | 1,885 |
| [algenta-runtime-native](https://pypi.org/project/algenta-runtime-native/) | 198 | 1,762 | 3,594 |
| [sqai](https://pypi.org/project/sqai/) | 170 | 1,623 | 8,822 |
| [ray-serve-algenta](https://pypi.org/project/ray-serve-algenta/) | 86 | 1,341 | 1,703 |
| [langchain-algenta](https://pypi.org/project/langchain-algenta/) | 103 | 1,235 | 1,829 |
| [llamaindex-algenta](https://pypi.org/project/llamaindex-algenta/) | 87 | 1,195 | 1,570 |
| [croniter-mojo](https://pypi.org/project/croniter-mojo/) | 69 | 968 | 968 |
| [jsonschema-mojo](https://pypi.org/project/jsonschema-mojo/) | 76 | 943 | 943 |
| [jsonpath-mojo](https://pypi.org/project/jsonpath-mojo/) | 77 | 935 | 935 |
| [sacrebleu-mojo](https://pypi.org/project/sacrebleu-mojo/) | 90 | 935 | 935 |
| [litellm-algenta](https://pypi.org/project/litellm-algenta/) | 85 | 792 | 1,375 |
| [haystack-algenta](https://pypi.org/project/haystack-algenta/) | 104 | 742 | 1,326 |
| [vllm-algenta](https://pypi.org/project/vllm-algenta/) | 107 | 738 | 1,332 |
| [pydantic-ai-algenta](https://pypi.org/project/pydantic-ai-algenta/) | 87 | 637 | 1,214 |
| [maf-algenta](https://pypi.org/project/maf-algenta/) | 44 | 568 | 942 |

### npm

| Package | 7 days | 30 days | All time |
|---|---:|---:|---:|
| [algenta-sdk](https://www.npmjs.com/package/algenta-sdk) | 131 | 5,357 | 7,695 |
| [@thyn-ai/sqai-mcp](https://www.npmjs.com/package/@thyn-ai/sqai-mcp) | 48 | 1,139 | 1,139 |
| [telys-ai](https://www.npmjs.com/package/telys-ai) | 15 | 893 | 1,710 |
| [@thyn-ai/sqai](https://www.npmjs.com/package/@thyn-ai/sqai) | 34 | 846 | 3,681 |
| [@thyn-ai/fuse-mojo-linux-x64](https://www.npmjs.com/package/@thyn-ai/fuse-mojo-linux-x64) | 14 | 803 | 803 |
| [@thyn-ai/sqai-ai-sdk](https://www.npmjs.com/package/@thyn-ai/sqai-ai-sdk) | 59 | 800 | 3,377 |
| [@thyn-ai/fuse-mojo-core](https://www.npmjs.com/package/@thyn-ai/fuse-mojo-core) | 10 | 723 | 723 |
| [@thyn-ai/fuse-mojo-darwin-arm64](https://www.npmjs.com/package/@thyn-ai/fuse-mojo-darwin-arm64) | 12 | 704 | 704 |
| [@thyn-ai/sqai-cli](https://www.npmjs.com/package/@thyn-ai/sqai-cli) | 14 | 610 | 3,143 |
| [algenta-tools](https://www.npmjs.com/package/algenta-tools) | 9 | 396 | 408 |
| [n8n-nodes-algenta](https://www.npmjs.com/package/n8n-nodes-algenta) | 12 | 220 | 240 |

### Hugging Face kernels

| Package | 30 days | All time |
|---|---:|---:|
| [thyn-ai/algenta-llm](https://huggingface.co/kernels/thyn-ai/algenta-llm) | 98 | 98 |
| [thyn-ai/algenta-stats](https://huggingface.co/kernels/thyn-ai/algenta-stats) | 26 | 26 |
| [thyn-ai/algenta-bits-time](https://huggingface.co/kernels/thyn-ai/algenta-bits-time) | 3 | 3 |
| [thyn-ai/algenta-graph](https://huggingface.co/kernels/thyn-ai/algenta-graph) | 3 | 3 |
| [thyn-ai/algenta-crypto](https://huggingface.co/kernels/thyn-ai/algenta-crypto) | 2 | 2 |
| [thyn-ai/algenta-finance](https://huggingface.co/kernels/thyn-ai/algenta-finance) | 2 | 2 |
| [thyn-ai/algenta-general-a](https://huggingface.co/kernels/thyn-ai/algenta-general-a) | 2 | 2 |
| [thyn-ai/algenta-general-b](https://huggingface.co/kernels/thyn-ai/algenta-general-b) | 2 | 2 |
| [thyn-ai/algenta-general-c](https://huggingface.co/kernels/thyn-ai/algenta-general-c) | 2 | 2 |
| [thyn-ai/algenta-general-d](https://huggingface.co/kernels/thyn-ai/algenta-general-d) | 2 | 2 |
| [thyn-ai/algenta-general-e](https://huggingface.co/kernels/thyn-ai/algenta-general-e) | 2 | 2 |
| [thyn-ai/algenta-geometry](https://huggingface.co/kernels/thyn-ai/algenta-geometry) | 2 | 2 |
| [thyn-ai/algenta-ml](https://huggingface.co/kernels/thyn-ai/algenta-ml) | 2 | 2 |
| [thyn-ai/algenta-networking](https://huggingface.co/kernels/thyn-ai/algenta-networking) | 2 | 2 |
| [thyn-ai/algenta-serialization](https://huggingface.co/kernels/thyn-ai/algenta-serialization) | 2 | 2 |
| [thyn-ai/algenta-signal](https://huggingface.co/kernels/thyn-ai/algenta-signal) | 2 | 2 |
| [thyn-ai/algenta-tensors](https://huggingface.co/kernels/thyn-ai/algenta-tensors) | 2 | 2 |
| [thyn-ai/algenta-text](https://huggingface.co/kernels/thyn-ai/algenta-text) | 2 | 2 |
| [thyn-ai/algenta-vision](https://huggingface.co/kernels/thyn-ai/algenta-vision) | 2 | 2 |
| [thyn-ai/algenta](https://huggingface.co/kernels/thyn-ai/algenta) | 0 | 0 |

### GitHub release assets

| Package | All time |
|---|---:|
| [thyn-ai/mojo-kernels](https://github.com/thyn-ai/mojo-kernels/releases) | 455 |
| [thyn-ai/algenta-sdk](https://github.com/thyn-ai/algenta-sdk/releases) | 62 |
| [thyn-ai/codna-cli](https://github.com/thyn-ai/codna-cli/releases) | 0 |
| [thyn-ai/sqai-mcp](https://github.com/thyn-ai/sqai-mcp/releases) | 0 |
| [thyn-ai/telys-sdk](https://github.com/thyn-ai/telys-sdk/releases) | 0 |

Sources: pypi: ClickPy (clickpy.clickhouse.com), the public ClickHouse copy of PyPI's download log, queried read-only at sql-clickhouse.clickhouse.com; npm: api.npmjs.org downloads API (point counts; all time = range sums since creation); github_releases: GitHub REST API, releases and their assets' download_count; huggingface: huggingface.co/api/kernels (downloads = last 30 days, downloadsAllTime).

Windows: day: the last full day, UTC (PyPI and npm); week: the 7 full days ending yesterday, UTC (PyPI and npm); month: the last 30 days (PyPI and npm: 30 full days ending yesterday; the Hub: its own rolling 30 days); all_time: every download on record: PyPI from the full download log (ClickPy), npm from its daily counts summed since the package was created, GitHub release assets since the first release, the Hub's downloadsAllTime.
