---
license: cc-by-4.0
pretty_name: Algenta arena results
tags:
  - benchmark
  - algenta
---

# Algenta arena results

Measurements written by the Algenta Spaces (`thyn-ai/algenta`, `thyn-ai/algenta-speed-arena`, `thyn-ai/algenta-governed-agent`) and read back by them. Every row is measured on the Space that wrote it; nothing here is typed in.

| File | Written by | Read by |
|---|---|---|
| `results.jsonl` | every race run on a Space (`CommitScheduler`) | leaderboards (`where = measured here` when `hardware_id` matches) |
| `qualified.json` | `spaces-requalify.yml` (nightly): cells that won 3/3 runs on the named hardware within 7 days | the Races tab: only qualified cells render as races; the rest are parity panels |
| `gpu_status.jsonl` | the GPU stage (`thyn-ai/algenta-governed-agent`): last measured decode throughput | the flagship's GPU tile (`last measured … · UTC`) |
| `flags.json` | operators | the fleet kill switch (`provider`, `gpu` spend features), polled every 60 s |

`results.jsonl` columns: `ts_utc, space_id, hardware_id, hardware, duel_id, size, n, algenta_median_ms, incumbent_median_ms, p95, mad, cv, ratio, parity, harness_commit, wheel_sha, incumbent_pin`.

Methodology: rulebook v0.3 (`docs/spaces/RULEBOOK.md` in the Algenta repository). Site: https://algenta.ai · Community: https://discord.gg/w8NDsph9an
