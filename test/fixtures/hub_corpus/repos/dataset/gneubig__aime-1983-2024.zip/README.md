---
language:
- en
license: cc0-1.0
task_categories:
- text-classification
pretty_name: AIME Problem Set 1983-2024
size_categories:
- 1K<n<10K
tags:
- mathematics
- education
- problem-solving
---

# AIME Problem Set 1983-2024

## Dataset Description

This dataset contains problems from the American Invitational Mathematics Examination (AIME) from 1983 to 2024. The AIME is a prestigious mathematics competition for high school students in the United States and Canada.

### Dataset Summary

- **Source**: [Kaggle - AIME Problem Set 1983-2024](https://www.kaggle.com/datasets/hemishveeraboina/aime-problem-set-1983-2024)
- **License**: [CC0: Public Domain](https://creativecommons.org/publicdomain/zero/1.0/)
- **Total Problems**: 2,250
- **Years Covered**: 1983 to 2024
- **Main Task**: Mathematics Problem Solving

### Dataset Structure

The dataset is provided in CSV format with the following columns:

1. **Year**: The year of the AIME contest (1983-2024)
2. **Problem Number**: The problem number within each contest (1-15)
3. **Problem**: The text of the mathematics problem
4. **Answer**: The correct answer to the problem

### Dataset Creation

This dataset was compiled from publicly available AIME problems and their solutions. It serves as a comprehensive resource for students, educators, and researchers interested in advanced high school mathematics and problem-solving techniques.

### Considerations for Use

- The dataset is intended for educational and research purposes.
- Users should be aware that the difficulty level of these problems is generally high, targeting advanced high school students with strong mathematical backgrounds.
- The dataset can be used for various purposes such as:
  - Training machine learning models for mathematical problem-solving
  - Analyzing trends in mathematical problem types over the years
  - Creating educational resources and practice materials

### Additional Information

The American Invitational Mathematics Examination (AIME) is a 15-question, 3-hour mathematics competition designed to identify the most talented high school mathematics students in the United States and Canada. It serves as a qualifying exam for the USA Mathematical Olympiad (USAMO) and is known for its challenging and creative problems that require deep mathematical insight and problem-solving skills.

## Citation and Acknowledgements

If you use this dataset in your research or projects, please cite:

```
@dataset{aime_1983_2024,
  author = {Hemish Veeraboina},
  title = {AIME Problem Set 1983-2024},
  year = {2023},
  publisher = {Kaggle},
  url = {https://www.kaggle.com/datasets/hemishveeraboina/aime-problem-set-1983-2024}
}
```

Special thanks to Hemish Veeraboina for compiling and sharing this valuable dataset on Kaggle.