---
license: apache-2.0
---

> **Languages:** [简体中文](README_ZH.md) · [English](README.md)

# dojo_benchmark_kline — Benchmark Index Bars

## Overview

Daily OHLCV for major broad and representative indices across US, CN, and HK (e.g. `^SPX`, `^HSI`, `000300.SS`). Each row is one index on one trade date.

## Files

| File | Description |
|------|-------------|
| `data.parquet` | Index daily bars |

## Key Fields

| Field | Description |
|-------|-------------|
| `symbol` | Index code (e.g. `^SPX`, `000300.SS`) |
| `kline_t` | Bar interval; `"1D"` for daily bars |
| `bar_time` | Trade date |
| `open` / `high` / `low` / `close` | OHLC |
| `vol` / `amount` | Volume / turnover |
| `change_p` | Percent change |

## Scale (reference)

~**4,650** rows (multiple indices × ~580 sessions; exact symbol set is defined by rows in `data.parquet`).

## Related Datasets

- [dojo_stock_kline](https://huggingface.co/datasets/AlphaDojo/dojo_stock_kline) — same schema, equity symbols
- [dojo_sector_precomputed](https://huggingface.co/datasets/AlphaDojo/dojo_sector_precomputed) — sector-level indices complement broad benchmarks
