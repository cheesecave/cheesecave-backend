> **Languages:** [简体中文](README_ZH.md) · [English](README.md)

# dojo_benchmark_kline — 大盘指数 K 线

## 概述

中美港主要**宽基指数**的日 K 线（如 `^SPX`、`^HSI`、`000300.SS`）。每行对应一个指数在一个交易日的 OHLCV。

## 文件

| 文件 | 说明 |
|------|------|
| `data.parquet` | 指数日 K 线 |

## 关键字段

| 字段 | 说明 |
|------|------|
| `symbol` | 指数代码（如 `^SPX`、`000300.SS`） |
| `kline_t` | 周期；日 K 为 `"1D"` |
| `bar_time` | 交易日 |
| `open` / `high` / `low` / `close` | OHLC |
| `vol` / `amount` | 成交量 / 成交额 |
| `change_p` | 涨跌幅（%） |

## 数据规模（参考）

约 **4,650** 行（若干指数 × 约 580 个交易日；具体指数以 `data.parquet` 中 `symbol` 为准）。

## 关联数据集

- [dojo_stock_kline](https://huggingface.co/datasets/AlphaDojo/dojo_stock_kline) — 相同 schema，个股标的
- [dojo_sector_precomputed](https://huggingface.co/datasets/AlphaDojo/dojo_sector_precomputed) — 板块指数，与宽基指数互补
