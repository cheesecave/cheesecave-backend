> **Languages:** [简体中文](README_ZH.md) · [English](README.md)

# dojo_sector_info — 板块 Taxonomy

## 概述

**三级板块分类体系**（L1 一级行业 → L2 产业链 → L3 细分赛道），含中英文名称与定义。

## 文件

| 文件 | 说明 |
|------|------|
| `data.parquet` | 板块树（每行一个 L1 节点，L2/L3 嵌套在 `children` 列） |

## 关键字段

| 字段 | 说明 |
|------|------|
| `id` | L1 板块 ID |
| `name` / `name_alias` | L1 英文名 / 中文别名 |
| `description` / `description_alias` | L1 英文 / 中文定义 |
| `children` | JSON 数组，嵌套 L2 → L3（含 `id`、`name`、`name_alias`、`description`、`level` 等） |
| `symbol` | 占位字段（如 `ALL`），非股票代码 |

### children 节点结构（L2 / L3）

```json
{
  "id": 13,
  "name": "Consumer Electronics",
  "name_alias": "消费电子",
  "description": "...",
  "description_alias": "...",
  "level": 2,
  "children": []
}
```

## 数据规模（参考）

约 **11** 行 L1 根节点，展开后数百条 L3 路径。

## 关联数据集

- [dojo_sector_symbol_relations](https://huggingface.co/datasets/AlphaDojo/dojo_sector_symbol_relations) — 股票归属到 L3 路径
- [dojo_sector_precomputed](https://huggingface.co/datasets/AlphaDojo/dojo_sector_precomputed) — 基于本 taxonomy 的预计算板块指数

## 注意

- [dojo_stock_info](https://huggingface.co/datasets/AlphaDojo/dojo_stock_info) 中的 `industry` / `sector` 与本文 taxonomy **是两套独立分类**。
