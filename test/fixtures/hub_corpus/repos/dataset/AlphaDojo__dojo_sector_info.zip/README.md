---
license: apache-2.0
---

> **Languages:** [简体中文](README_ZH.md) · [English](README.md)

# dojo_sector_info — Sector Taxonomy

## Overview

Three-level sector taxonomy (L1 industry → L2 chain → L3 sub-sector) with bilingual Chinese/English names and definitions.

## Files

| File | Description |
|------|-------------|
| `data.parquet` | Taxonomy tree (one L1 row each; L2/L3 nested in `children`) |

## Key Fields

| Field | Description |
|-------|-------------|
| `id` | L1 sector ID |
| `name` / `name_alias` | L1 English name / Chinese alias |
| `description` / `description_alias` | L1 English / Chinese definition |
| `children` | JSON array nesting L2 → L3 nodes (`id`, `name`, `name_alias`, `description`, `level`, …) |
| `symbol` | Placeholder (e.g. `ALL`), not a stock ticker |

### children Node Shape (L2 / L3)

```json
{
  "id": 13,
  "name": "Consumer Electronics",
  "name_alias": "消费电子",
  "description": "...",
  "description_alias": "...",
  "level": 2,
  "children": []
}
```

## Scale (reference)

~**11** L1 root rows; hundreds of L3 paths when the tree is expanded.

## Related Datasets

- [dojo_sector_symbol_relations](https://huggingface.co/datasets/AlphaDojo/dojo_sector_symbol_relations) — ticker assignments to L3 paths
- [dojo_sector_precomputed](https://huggingface.co/datasets/AlphaDojo/dojo_sector_precomputed) — precomputed indices built from this taxonomy

## Notes

- Vendor `industry` / `sector` in [dojo_stock_info](https://huggingface.co/datasets/AlphaDojo/dojo_stock_info) is a **separate** classification from this taxonomy.
