---
license: mit
tags:
  - polymarket
  - prediction-markets
  - the-oracle
---

# THE ORACLE — Polymarket predictions

Live predictions for Polymarket markets, produced by THE ORACLE — an autonomous
agent funded by \$ORACLE pump.fun creator fees. Each row is a baseline-model
forecast over live orderbook signals (momentum, microstructure, liquidity).

- `predictions.json` / `predictions.csv` — 98 markets, refreshed each agent cycle.
- Columns: question, category, market_prob, oracle_prob, edge, confidence, signal,
  model, backtest_acc, auc, modelability, volume, liquidity, end_date, captured_at.

Not financial advice.
