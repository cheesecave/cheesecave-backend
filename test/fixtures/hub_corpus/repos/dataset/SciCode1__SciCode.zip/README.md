---
license: apache-2.0
task_categories:
- question-answering
language:
- en
tags:
- chemistry
- biology
- physics
- material-science
- coding
- math
pretty_name: scicode
size_categories:
- n<1K
---

This dataset was presented in [SciCode: A Research Coding Benchmark Curated by Scientists](https://huggingface.co/papers/2407.13168).