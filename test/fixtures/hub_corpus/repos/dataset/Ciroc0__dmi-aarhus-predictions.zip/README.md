---
license: cc-by-4.0
tags:
- weather
- aarhus
- denmark
- predictions
- forecast
- machine-learning
---

# DMI Aarhus Predictions

Prediction and frontend contract dataset for the Aarhus weather pipeline. Maintained by `Ciroc0`.

## Primary files

| File | Purpose | Produced by |
| --- | --- | --- |
| `predictions_latest.parquet` | Current future + verified prediction store | `dmi-collector` |
| `frontend_snapshot.json` | Primary integration contract for the Vercel frontend | `dmi-collector` |

## Compatibility files

| File | Status | Notes |
| --- | --- | --- |
| `predictions.parquet` | Legacy | Still read by compatibility code |
| `history_snapshot.json` | Legacy | Only used by older frontend fallback logic |

## Update pattern

- `predictions_latest.parquet` is rewritten on scheduled prediction runs
- verification updates actual columns once the target hour is in the past
- `frontend_snapshot.json` is regenerated after prediction and verification writes

## Schema highlights for `predictions_latest.parquet`

- `target_timestamp`
- `reference_time`
- `lead_time_hours`
- `lead_bucket`
- `prediction_made_at`
- `city`
- `verified`
- `dmi_temperature_2m_pred`
- `dmi_windspeed_10m_pred`
- `dmi_windgusts_10m_pred`
- `dmi_precipitation_probability_pred`
- `dmi_precipitation_pred`
- `ml_temp`
- `ml_wind_speed`
- `ml_wind_gust`
- `ml_rain_prob`
- `ml_rain_amount`
- `actual_temp`
- `actual_wind_speed`
- `actual_wind_gust`
- `actual_precipitation`
- `actual_rain_event`
- `actual_rain_amount`

## Snapshot contract

`frontend_snapshot.json` is the main public-facing contract and contains:

- location metadata
- generated timestamp
- target labels and explanations
- current weather block
- 48-hour forecast rows
- historical backtest payload
- verification metrics
- lead-bucket summary
- feature importance
- model info
- alert rows

## Attribution

This dataset is released under `CC BY 4.0`.

Please preserve attribution to:

- `Ciroc0`
- `Open-Meteo - https://open-meteo.com`
- `DMI / DMI HARMONIE`
