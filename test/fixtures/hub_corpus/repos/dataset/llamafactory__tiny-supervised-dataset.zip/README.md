---
dataset_info:
  features:
  - name: instruction
    dtype: string
  - name: input
    dtype: string
  - name: output
    dtype: string
license: apache-2.0
task_categories:
- text-generation
- question-answering
language:
- en
- zh
tags:
- llama-factory
size_categories:
- n<1K
---
