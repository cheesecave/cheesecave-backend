---
dataset_info:
- config_name: conversational_implicit_prompt_preference
  features:
  - name: chosen
    list:
    - name: content
      dtype: string
    - name: role
      dtype: string
  - name: rejected
    list:
    - name: content
      dtype: string
    - name: role
      dtype: string
  splits:
  - name: train
    num_bytes: 2755
    num_examples: 17
  - name: test
    num_bytes: 386
    num_examples: 2
  download_size: 6623
  dataset_size: 3141
- config_name: conversational_language_modeling
  features:
  - name: messages
    list:
    - name: content
      dtype: string
    - name: role
      dtype: string
  splits:
  - name: train
    num_bytes: 1399
    num_examples: 17
  - name: test
    num_bytes: 210
    num_examples: 2
  download_size: 3723
  dataset_size: 1609
- config_name: conversational_preference
  features:
  - name: prompt
    list:
    - name: content
      dtype: string
    - name: role
      dtype: string
  - name: chosen
    list:
    - name: content
      dtype: string
    - name: role
      dtype: string
  - name: rejected
    list:
    - name: content
      dtype: string
    - name: role
      dtype: string
  splits:
  - name: train
    num_bytes: 2070
    num_examples: 17
  - name: test
    num_bytes: 295
    num_examples: 2
  download_size: 8123
  dataset_size: 2365
- config_name: conversational_prompt_completion
  features:
  - name: prompt
    list:
    - name: content
      dtype: string
    - name: role
      dtype: string
  - name: completion
    list:
    - name: content
      dtype: string
    - name: role
      dtype: string
  splits:
  - name: train
    num_bytes: 1467
    num_examples: 17
  - name: test
    num_bytes: 218
    num_examples: 2
  download_size: 5796
  dataset_size: 1685
- config_name: conversational_prompt_only
  features:
  - name: prompt
    list:
    - name: content
      dtype: string
    - name: role
      dtype: string
  splits:
  - name: train
    num_bytes: 821
    num_examples: 17
  - name: test
    num_bytes: 107
    num_examples: 2
  download_size: 3326
  dataset_size: 928
- config_name: conversational_unpaired_preference
  features:
  - name: prompt
    list:
    - name: content
      dtype: string
    - name: role
      dtype: string
  - name: completion
    list:
    - name: content
      dtype: string
    - name: role
      dtype: string
  - name: label
    dtype: bool
  splits:
  - name: train
    num_bytes: 1441
    num_examples: 17
  - name: test
    num_bytes: 219
    num_examples: 2
  download_size: 6421
  dataset_size: 1660
- config_name: standard_implicit_prompt_preference
  features:
  - name: chosen
    dtype: string
  - name: rejected
    dtype: string
  splits:
  - name: train
    num_bytes: 1537
    num_examples: 17
  - name: test
    num_bytes: 258
    num_examples: 2
  download_size: 4330
  dataset_size: 1795
- config_name: standard_language_modeling
  features:
  - name: text
    dtype: string
  splits:
  - name: train
    num_bytes: 744
    num_examples: 17
  - name: test
    num_bytes: 136
    num_examples: 2
  download_size: 2457
  dataset_size: 880
- config_name: standard_preference
  features:
  - name: prompt
    dtype: string
  - name: chosen
    dtype: string
  - name: rejected
    dtype: string
  splits:
  - name: train
    num_bytes: 1213
    num_examples: 17
  - name: test
    num_bytes: 205
    num_examples: 2
  download_size: 4466
  dataset_size: 1418
- config_name: standard_prompt_completion
  features:
  - name: prompt
    dtype: string
  - name: completion
    dtype: string
  splits:
  - name: train
    num_bytes: 812
    num_examples: 17
  - name: test
    num_bytes: 144
    num_examples: 2
  download_size: 3231
  dataset_size: 956
- config_name: standard_prompt_only
  features:
  - name: prompt
    dtype: string
  splits:
  - name: train
    num_bytes: 460
    num_examples: 17
  - name: test
    num_bytes: 69
    num_examples: 2
  download_size: 2044
  dataset_size: 529
- config_name: standard_stepwise
  features:
  - name: prompt
    dtype: string
  - name: completions
    sequence: string
  - name: label
    sequence: bool
  splits:
  - name: train
    num_bytes: 1402.9473684210527
    num_examples: 17
  - name: test
    num_bytes: 165.05263157894737
    num_examples: 2
  download_size: 5033
  dataset_size: 1568.0
- config_name: standard_stepwise_supervision
  features:
  - name: prompt
    dtype: string
  - name: completions
    sequence: string
  - name: labels
    sequence: bool
  splits:
  - name: train
    num_bytes: 1382
    num_examples: 17
  - name: test
    num_bytes: 187
    num_examples: 2
  download_size: 5039
  dataset_size: 1569
- config_name: standard_unpaired_preference
  features:
  - name: prompt
    dtype: string
  - name: completion
    dtype: string
  - name: label
    dtype: bool
  splits:
  - name: train
    num_bytes: 840
    num_examples: 17
  - name: test
    num_bytes: 131
    num_examples: 2
  download_size: 3861
  dataset_size: 971
configs:
- config_name: conversational_implicit_prompt_preference
  data_files:
  - split: train
    path: conversational_implicit_prompt_preference/train-*
  - split: test
    path: conversational_implicit_prompt_preference/test-*
- config_name: conversational_language_modeling
  data_files:
  - split: train
    path: conversational_language_modeling/train-*
  - split: test
    path: conversational_language_modeling/test-*
- config_name: conversational_preference
  data_files:
  - split: train
    path: conversational_preference/train-*
  - split: test
    path: conversational_preference/test-*
- config_name: conversational_prompt_completion
  data_files:
  - split: train
    path: conversational_prompt_completion/train-*
  - split: test
    path: conversational_prompt_completion/test-*
- config_name: conversational_prompt_only
  data_files:
  - split: train
    path: conversational_prompt_only/train-*
  - split: test
    path: conversational_prompt_only/test-*
- config_name: conversational_unpaired_preference
  data_files:
  - split: train
    path: conversational_unpaired_preference/train-*
  - split: test
    path: conversational_unpaired_preference/test-*
- config_name: standard_implicit_prompt_preference
  data_files:
  - split: train
    path: standard_implicit_prompt_preference/train-*
  - split: test
    path: standard_implicit_prompt_preference/test-*
- config_name: standard_language_modeling
  data_files:
  - split: train
    path: standard_language_modeling/train-*
  - split: test
    path: standard_language_modeling/test-*
- config_name: standard_preference
  data_files:
  - split: train
    path: standard_preference/train-*
  - split: test
    path: standard_preference/test-*
- config_name: standard_prompt_completion
  data_files:
  - split: train
    path: standard_prompt_completion/train-*
  - split: test
    path: standard_prompt_completion/test-*
- config_name: standard_prompt_only
  data_files:
  - split: train
    path: standard_prompt_only/train-*
  - split: test
    path: standard_prompt_only/test-*
- config_name: standard_stepwise
  data_files:
  - split: train
    path: standard_stepwise/train-*
  - split: test
    path: standard_stepwise/test-*
- config_name: standard_stepwise_supervision
  data_files:
  - split: train
    path: standard_stepwise_supervision/train-*
  - split: test
    path: standard_stepwise_supervision/test-*
- config_name: standard_unpaired_preference
  data_files:
  - split: train
    path: standard_unpaired_preference/train-*
  - split: test
    path: standard_unpaired_preference/test-*
---
