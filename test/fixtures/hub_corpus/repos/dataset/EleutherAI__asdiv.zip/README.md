---
license: cc-by-nc-4.0
dataset_info:
  config_name: asdiv
  features:
  - name: body
    dtype: string
  - name: question
    dtype: string
  - name: solution_type
    dtype: string
  - name: answer
    dtype: string
  - name: formula
    dtype: string
  splits:
  - name: validation
    num_bytes: 501489
    num_examples: 2305
  download_size: 266768
  dataset_size: 501489
configs:
- config_name: asdiv
  data_files:
  - split: validation
    path: asdiv/validation-*
  default: true
---
