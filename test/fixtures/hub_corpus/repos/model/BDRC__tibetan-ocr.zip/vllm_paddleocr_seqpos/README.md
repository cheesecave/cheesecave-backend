# vllm-paddleocr-seqpos

A tiny [vLLM](https://github.com/vllm-project/vllm) plugin that makes PaddleOCR-VL serve in the
**`sequential` image-token position regime** (1D positions for image tokens) instead of vLLM's
built-in **`grid`** regime (2D image-grid M-RoPE).

Use it to serve any PaddleOCR-VL checkpoint that was **trained/validated with
`image_token_positions=sequential`** (i.e. with `mm_token_type_ids` zeroed) — e.g.
`elie_v6_coarse_grow26_ep2`. Without it, vLLM silently serves such a checkpoint in the wrong
regime and the model regresses.

## Background: the two regimes

PaddleOCR-VL uses M-RoPE. A per-token mask, `mm_token_type_ids`, decides how *image* tokens are
positioned:

- **`sequential`** — mask zeroed → image tokens get plain 1D positions, exactly like text
  (M-RoPE degenerates to standard 1D RoPE). This is the regime our checkpoints are trained in.
- **`grid`** — mask marked → image tokens get native 2D image-grid M-RoPE.

The HF reference path honors both (`deploy/fast_inference/bench.py --backend hf
--image-token-positions {sequential,grid}`), and `patch_checkpoint.py` warns that serving the
`sequential` regime needs an *engine-side* override. This package is that override for vLLM.

## Why a plugin is needed (and why there's no simpler knob)

vLLM's in-tree model `vllm/model_executor/models/paddleocr_vl.py` (checked on 0.27.1) computes
positions itself in `PaddleOCRVLForConditionalGeneration.get_mrope_input_positions`. It
**unconditionally builds the 2D grid** from `image_grid_thw`/`mm_features` and **never reads
`mm_token_type_ids`**. Consequences:

- There is **no `mm_processor_kwargs` / processor knob** to switch it to sequential — the regime
  lives in vLLM's own position code, not in the processor output vLLM consumes.
- `get_mrope_input_positions` runs in a **separate `EngineCore`/worker process**, so a
  monkeypatch applied in the driver process (before `LLM(...)`) does **not** reach it.

vLLM does, however, call `vllm.general_plugins` entry points in **process0, the EngineCore
process, and every worker** (`vllm/plugins/__init__.py`). So the robust, version-stable fix is a
general plugin that overrides that one method wherever it runs. That's all this package does.

## What it does

On load, and only when the environment variable `OCR_VLLM_IMAGE_TOKEN_POSITIONS=sequential`,
it replaces `get_mrope_input_positions` with a version that returns plain 1D sequential positions
(`arange(n)` broadcast across the 3 M-RoPE sections, `mrope_position_delta=0`) for the whole
sequence, image tokens included. The image features still merge via `input_ids ==
config.image_token_id`, so zeroing positions does **not** remove the image — it only changes the
position encoding.

It is a **strict no-op** for any other value (`grid`, unset), so grid-trained checkpoints are
untouched. It is idempotent (vLLM may load plugins more than once per process).

## Install

Install into the **same Python environment that runs vLLM** (e.g. the DLAMI `/opt/pytorch` venv
on the serving box). No dependencies are declared on purpose — the plugin only touches
`vllm`/`torch`/`numpy`, which are already present in a serving env.

```bash
/opt/pytorch/bin/pip install /path/to/deploy/vllm_paddleocr_seqpos
```

Verify the entry point is registered:

```bash
python -c "from importlib.metadata import entry_points; \
print([e.value for e in entry_points(group='vllm.general_plugins') if e.name=='paddleocr_seqpos'])"
# -> ['vllm_paddleocr_seqpos:apply']
```

## Use

Set the env var in the process that constructs `LLM(...)` **before** the engine starts; the
EngineCore/worker children inherit it:

```bash
export OCR_VLLM_IMAGE_TOKEN_POSITIONS=sequential   # or 'grid' / unset to disable (no-op)
```

Then serve/construct vLLM as usual. On activation you'll see a one-line WARNING:
`paddleocr-seqpos: forcing SEQUENTIAL (1D) image-token M-RoPE for PaddleOCR-VL ...`.

In the OCR web-app this is automated: `ocr_app.worker.paddle_engine` resolves the checkpoint's
regime (from `experiment_config.json` / `info.json`, defaulting to `sequential`) and sets this
env var itself before loading the engine.

## Verification (vLLM 0.27.1, A10G)

Against the production path (chat-template prompt, pyvips long-side 2500, greedy + DRY), on the
6-page `TSAM-CHOE.pdf`, under default multiprocessing:

| page | `grid` (stock vLLM) | `sequential` (this plugin) |
| ---- | ------------------- | -------------------------- |
| 2    | 816 gen-tokens      | **479 gen-tokens** (matches the HF `--image-token-positions sequential` oracle) |
| 4    | drops a catalog entry (`༤༨` → `རི་ཁྲོད`) | correct `༤༨ ཆོས་གསུམ / ༤༩ རི་ཁྲོད / ༥༠` |

`grid` stays at 816 with the plugin installed but the flag unset/`grid` (confirmed no-op).

## Alternative

If you'd rather not run a serving-side plugin, **train/validate the checkpoint in the `grid`
regime** (`--image-token-positions grid`) and record `image_token_positions: grid` in its
`experiment_config.json`. Grid is vLLM's native path, so serving then needs no plugin. This
package exists so you don't *have* to retrain to serve existing `sequential` checkpoints.

## Files

- `vllm_paddleocr_seqpos/__init__.py` — the plugin (`apply()` entry point + the sequential
  `get_mrope_input_positions`).
- `pyproject.toml` — declares the `vllm.general_plugins` → `paddleocr_seqpos = vllm_paddleocr_seqpos:apply`
  entry point.
