Field                                                                                                  |  Response
:------------------------------------------------------------------------------------------------------|:---------------------------------------------------------------------------------
Intended Task/Domain:                                                                   |  Speech Recognition
Model Type:                                                                                            |  FastConformer-RNNT
Intended Users:                                                                                        |  People who work with conversational AI models and need to transcribe speech to text with low latency in streaming scenarios.
Output:                                                                                                |  Text tokens
Describe how the model works:                                                                          |  Raw audio is passed into the model, and the model outputs text.
Name the adversely impacted groups this has been tested to deliver comparable outcomes regardless of:  |  Not Applicable
Technical Limitations & Mitigation:                                                                    |  The model is trained on only a limited amount of English speech data; therefore, it may not work well for other languages, and its performance may degrade in noisy environments.
Verified to have met prescribed NVIDIA quality standards:  |  Yes
Performance Metrics:                                                                                   |  Word Error Rate (WER)
Potential Known Risks:                                                                                 |  The model may produce incorrect transcriptions if the audio is noisy or the speech is not clear, and predicted text may be inaccurate in domains that are not well-represented in the training data.
Licensing:                                                                                             | [NVIDIA Open Model License](https://www.nvidia.com/en-us/agreements/enterprise-software/nvidia-open-model-license/)

