Field                                                                                                                              |  Response
:----------------------------------------------------------------------------------------------------------------------------------|:-----------------------------------------------
Generatable or reverse engineerable personal data?                                                     |  No
Personal data used to create this model?                                                                                       |  Yes - Voice
Was consent obtained for any personal data used?                                                                                             |  Yes
Is a mechanism in place to honor data subject right of access or deletion of personal data?                                        |  Yes 
If personal data was collected for the development of the model, was it collected directly by NVIDIA?                                            |  Yes
If personal data was collected for the development of the model by NVIDIA, do you maintain or have access to disclosures made to data subjects?  |  Yes
If personal data was collected for the development of this AI model, was it minimized to only what was required?                                 |  Yes
Is there provenance for all datasets used in training?                                                                                |  Yes
Does data labeling (annotation, metadata) comply with privacy laws?                                                                |  Yes
Is data compliant with data subject requests for data correction or removal, if such a request was made?                           |  The data is compliant where applicable, but is not applicable for all data.
Applicable Privacy Policy        | [https://www.nvidia.com/en-us/about-nvidia/privacy-policy/]
