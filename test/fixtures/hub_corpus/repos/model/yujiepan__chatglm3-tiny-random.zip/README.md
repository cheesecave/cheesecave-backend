---
library_name: transformers
pipeline_tag: text-generation
inference: true
widget:
- text: Hello!
  example_title: Hello world
  group: Python
---

This model is randomly initialized, using the config from [THUDM/chatglm3-6b-128k](https://huggingface.co/THUDM/chatglm3-6b-128k/blob/main/config.json) but with smaller size. 
Note the model is in float16.

Codes:
```python
import transformers
import torch
import os
from huggingface_hub import create_repo, upload_folder

source_model_id = 'THUDM/chatglm3-6b-128k'
tiny_random_name = 'chatglm3-tiny-random'
save_path = f'/tmp/yujiepan/{tiny_random_name}'
repo_id = f'yujiepan/{tiny_random_name}'

config = transformers.AutoConfig.from_pretrained(
    source_model_id, trust_remote_code=True)
config.hidden_size = 4
config.ffn_hidden_size = 6
config.num_attention_heads = 4
config.kv_channels = 2
config.num_layers = 2
config.torch_dtype = torch.float16

model = transformers.AutoModelForCausalLM.from_config(
    config, trust_remote_code=True, torch_dtype=torch.float16)
model = model.half()

tokenizer = transformers.AutoTokenizer.from_pretrained(
    source_model_id, trust_remote_code=True)

# result = transformers.pipelines.pipeline(
#     'text-generation',
#     model=model, tokenizer=tokenizer,
#     device=0,
#     max_new_tokens=16,
# )('Hello')
# print(result)
model = model.cuda()
response, history = model.chat(tokenizer, "Hi", history=[], max_length=32)
print(response)

model.save_pretrained(save_path)
tokenizer.save_pretrained(save_path)

os.system(f'ls -alh {save_path}')
create_repo(repo_id, exist_ok=True)
upload_folder(repo_id=repo_id, folder_path=save_path)
```
