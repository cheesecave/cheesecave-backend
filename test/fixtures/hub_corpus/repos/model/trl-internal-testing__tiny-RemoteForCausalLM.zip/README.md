---
library_name: transformers
tags:
- trl
---

# Tiny RemoteForCausalLM

This is a minimal model built for unit tests in the [TRL](https://github.com/huggingface/trl) library.
